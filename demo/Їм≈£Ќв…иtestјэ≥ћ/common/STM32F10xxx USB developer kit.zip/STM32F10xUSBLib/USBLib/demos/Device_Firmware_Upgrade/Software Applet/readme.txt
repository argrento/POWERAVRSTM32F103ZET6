/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* File Name          : readme.txt
* Author             : MCD Application Team
* Date First Issued  : 05/21/2007
* Description        : Description of the PC APPLI DfuSe - 
                     : DFU STMicroelectronics Extension.
********************************************************************************
* History:
* 05/21/2007: V0.3
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

Directory contents
==================

     - setup.exe     Install file PC DFU application
     + images        Directory containing STM32F10x USB demos images

How to use it
=============

  1-  Run "Setup.exe" to install the PC APPLI DfuSe program to the folder of your choice
      (default path: C:\Program Files\STMicroelectronics\DfuSe)
       
  2-  Load your firmware project using your prefered Toolchain and load the DFU image
      using JTAG for the first time.   
      
  3-  Run the Board and then Connect your USB cable, the first time you have to
      Install your device with the driver and the inf file already included in
      the install directory.
      
      Please note this inf file and the GUI sample are configured only
      for devices in DFU mode (VID 0x0483, PID 0xDF11)
      
  4- Use it ! : Upgrade your board using the included images and then "Leave DFU Mode"

******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE******
