/**
  @page CEC_Demo CEC_Demo  Readme File
  
  @verbatim
  ******************** (C) COPYRIGHT 2009 STMicroelectronics *******************
  * @file CEC_Demo/readme.txt 
  * @author   MCD Application Team
  * @version  V2.0.0
  * @date     04/27/2009
  * @brief    Description of the STM32F10xxx CEC library.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Description 

This firmware contains a CEC library and a demo running on the STM3210B-EVAL board.

The CEC library contains the basic CEC functions for CEC communication, which are:
    - Send/Receive  CEC Start bit.
    - Send/Receive  CEC ACK bit "logical 0".
    - Send/Receive  CEC data bit.
    - Send/Receive  CEC data byte.
    - Send/Receive  CEC data frame.
  
For more information, please refer to the user manual provided with this firmware.

The demo illustrates the use of the CEC communication between three devices (3 x STM3210B-EVAL boards).
Each device can send a frame to the two other devices by pressing the user key button on
the EVAL board. Pressing the key button, sends a frame to one device and the next press
sends to the second device.
The information of CEC send/receive of each device is displayed on its LCD.


@par Directory contents 

The demo directory contains three directories corresponding to each device.  
  - 1rst_CEC_Device: corresponding two the device having the address 0x1. 
  - 2nd_CEC_Device: corresponding two the device having the address 0x2. 
  - 3rd_CEC_Device: corresponding two the device having the address 0x3. 

The 1rst_CEC_Device directory contains:
  
  - inc: containing the user header files 
      - 1rst_CEC_Device/inc/stm32f10x_conf.h  Library Configuration file
      - 1rst_CEC_Device/inc/stm32f10x_it.h    Interrupt handlers header file
      - 1rst_CEC_Device/inc/stm3210b_lcd.h    LCD firmware driver header file
      - 1rst_CEC_Device/inc/fonts.h           LCD fonts size definition

  - src: containg the user source files  
      - 1rst_CEC_Device/src/main.c            Main program
      - 1rst_CEC_Device/src/stm32f10x_it.c    Interrupt handlers
      - 1rst_CEC_Device/src/stm3210b_lcd.c    LCD driver for Liquid Crystal Display Module of STM3210B-EVAL board.

The 2nd_CEC_Device directory contains:
  
  - inc: containing the user header files 
      - 2nd_CEC_Device/inc/stm32f10x_conf.h  Library Configuration file
      - 2nd_CEC_Device/inc/stm32f10x_it.h    Interrupt handlers header file
      - 2nd_CEC_Device/inc/stm3210b_lcd.h    LCD firmware driver header file
      - 2nd_CEC_Device/inc/fonts.h           LCD fonts size definition

  - src: containg the user source files  
      - 2nd_CEC_Device/src/main.c            Main program
      - 2nd_CEC_Device/src/stm32f10x_it.c    Interrupt handlers
      - 2nd_CEC_Device/src/stm3210b_lcd.c    LCD driver for Liquid Crystal Display Module of STM3210B-EVAL board.
      

The 3rd_CEC_Device directory contains:
  
  - inc: containing the user header files 
      - 3rd_CEC_Device/inc/stm32f10x_conf.h  Library Configuration file
      - 3rd_CEC_Device/inc/stm32f10x_it.h    Interrupt handlers header file
      - 3rd_CEC_Device/inc/stm3210b_lcd.h    LCD firmware driver header file
      - 3rd_CEC_Device/inc/fonts.h           LCD fonts size definition

  - src: containg the user source files  
      - 3rd_CEC_Device/src/main.c            Main program
      - 3rd_CEC_Device/src/stm32f10x_it.c    Interrupt handlers
      - 3rd_CEC_Device/src/stm3210b_lcd.c    LCD driver for Liquid Crystal Display Module of STM3210B-EVAL board.
            
@par Hardware and Software environment

  - This example runs on STM32F10x High-Density, STM32F10x Medium-Density and
    STM32F10x Low-Density Devices.
  
  - This example has been tested with STMicroelectronics STM3210B-EVAL evaluation 
    boards and can be easily tailored to any other supported device and development 
    board. For the demo, You can connect three STM3210B-EVAL boards. The ground 
    (GND) have to be common of all boards.
    
  - Connect the boards by connecting all GPIOA.0 together.
   
  - It's mondatory to connect a resistor (around 27K) to VDD and any GPIOA.0 of 
    any board.

@note
 - If three Eval boards are not available, the use of only two boards is possible.

         
@par How to use it ? 

 - Load the project image of 1st_Device to the first board.
 - Load the project image of 2nd_Device to the second board.
 - Load the project image of 3rd_Device to the third board.
 - If only two boards are available, load any pair of project image two the two boards.

In order to load the 1st CEC Device Demo code, you have do the following:

- EWARMv5: 
    - Open the 1st_Device.eww workspace
    - In the workspace toolbar select the project config:
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all
    - Load project image: Project->Debug
    - Run program: Debug->Go(F5)

 - RVMDK 
    - Open the 1st_Device.Uv2 project
    - In the configuration toolbar(Project->properties) select the project config:
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->build project
    - Load project image: Debug->start(ctrl+D)
    - Run program: Debug->Run(ctrl+F9)

 - RIDE 
    - Open the 1st_Device.rprj project
    - In the build toolbar select the project config:  
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all target files
    - Load project image: Debug->Start/Stop Debug Session
    - Run program: Debug->Run (F5)
    
In order to load the 2nd CEC Device Demo code, you have do the following:

- EWARMv5: 
    - Open the 2nd_Device.eww workspace
    - In the workspace toolbar select the project config:
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all
    - Load project image: Project->Debug
    - Run program: Debug->Go(F5)

 - RVMDK 
    - Open the 2nd_Device.Uv2 project
    - In the configuration toolbar(Project->properties) select the project config:
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->build project
    - Load project image: Debug->start(ctrl+D)
    - Run program: Debug->Run(ctrl+F9)

 - RIDE 
    - Open the 2nd_Device.rprj project
    - In the build toolbar select the project config:  
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all target files
    - Load project image: Debug->Start/Stop Debug Session
    - Run program: Debug->Run (F5)
    
In order to load the 3rd CEC Devicee Demo code, you have do the following:

- EWARMv5: 
    - Open the 3rd_Device.eww workspace
    - In the workspace toolbar select the project config:
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all
    - Load project image: Project->Debug
    - Run program: Debug->Go(F5)

 - RVMDK 
    - Open the 3rd_Device.Uv2 project
    - In the configuration toolbar(Project->properties) select the project config:
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->build project
    - Load project image: Debug->start(ctrl+D)
    - Run program: Debug->Run(ctrl+F9)

 - RIDE 
    - Open the 3rd_Device.rprj project
    - In the build toolbar select the project config:  
        - STM3210B-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all target files
    - Load project image: Debug->Start/Stop Debug Session
    - Run program: Debug->Run (F5)       

@note
 - Low-density devices are STM32F101xx and STM32F103xx microcontrollers where
   the Flash memory density ranges between 16 and 32 Kbytes.
 - Medium-density devices are STM32F101xx and STM32F103xx microcontrollers where
   the Flash memory density ranges between 32 and 128 Kbytes.
 - High-density devices are STM32F101xx and STM32F103xx microcontrollers where
   the Flash memory density ranges between 256 and 512 Kbytes.  

 * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
 */
