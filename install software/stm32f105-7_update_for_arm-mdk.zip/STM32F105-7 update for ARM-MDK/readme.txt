/******************** (C) COPYRIGHT 2009 STMicroelectronics ********************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V1.0
* Date               : 23/06/2009
* Description        : This file describes how to add STM32F105xC/7xC 
                       (Connectivity Line)devices support for ARM-MDK v3.50 and laters
********************************************************************************

This package contains the needed files to be installed in order to support
STM32F105/7 Connectivity Line by ARM-MDK v3.50 and laters.

1. Adding new connection for STM32F105/7
========================================
To add the STM32F105xC/7xC to ARM-MDK devices database with a complete description:
(CPU Frequency, RAM and FLASH size and peripheral descriptions), just overwrite 
the UV3.cdb file located at:
[Install Directory]\Keil\uv3 by the uv3.cdb provided in this patch (ARM-MDK should be closed)

2. Installing flash loader for STM32F105/7 
==========================================
To add the flasher tool just copy the FLM file provided in this package at:
[Install Directory]\Keil\ARM\Flash

STM32F10x_256.FLM will work with Flash size range up to 256KB (2K page)

To Configure the flash loader:

1. Go to: Project ->option for target "��."Utility tab
2. Click "Use Target Driver for Flash Programming"
3. Select "ULINK Cortex-M3 Debugger"
4. Click on Settings
5. On the Flash Download tab Click on "erase full chip", "program" and "verify"
6. Click on "add" button at the bottom of the window
7. The "Add Flash Programming Algorithm" window will appear, choose 
"STM32F10x Connectivity Line Flash".
8. Click on "Add"
9. Click "Ok" 

Now you Application Flash loader is configured. You are ready to start!!  


Note:
======
Before installing the files mentioned above, you need to have ARM-MDK V3.50 or 
laters installed. 
You can downlaod ARM-MDK from keil web site @ www.keil.com


******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE******
