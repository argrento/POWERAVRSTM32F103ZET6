/**
  @page binary_template AN2557 Binary Template Readme file
  
  @verbatim
  ******************** (C) COPYRIGHT 2009 STMicroelectronics *******************
  * @file    IAP/binary_template/readme.txt 
  * @author  MCD Application Team
  * @version V3.1.0
  * @date    07/27/2009
  * @brief   Description of the binary_template directory.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Description

This directory contains a set of sources files that build the application to be
loaded into Flash memory using In-Application Programming (IAP, through USART).

To build such application, some special configuration has to be peformed:
1. Set the program load address at 0x08002000, using your toolchain linker file
2. Relocate the vector table at address 0x08002000, using the "NVIC_SetVectorTable"
   function.
 
The SysTick example provided within the STM32F10x Standard Peripherals library 
examples is used as illustration.
This example configures the SysTick to generate a time base equal to 1 ms.
The system clock is set to 72 MHz, the SysTick is clocked by the AHB clock (HCLK).
A "Delay" function is implemented based on the SysTick end-of-count event.
Four LEDs are toggled with a timing defined by the Delay function.


@par Directory contents 

 - "binary_template\EWARMv5": This folder contains a pre-configured project file 
                              that produces a binary image of SysTick example to 
                              be loaded with IAP.

 - "binary_template\RIDE": This folder contains a pre-configured project file 
                           that produces a binary image of SysTick example to be 
                           loaded with IAP.

 - "binary_template\RVMDK": This folder contains a pre-configured project file 
                            that produces a binary image of SysTick example to be 
                            loaded with IAP.
                           
 - "binary_template\inc": contains the binary_template firmware header files 
     - binary_template/inc/stm32f10x_conf.h    Library Configuration file
     - binary_template/inc/stm32f10x_it.h      Header for stm32f10x_it.c
     - binary_template/inc/main.h              Header for main.c
     
 - "binary_template\src": contains the binary_template firmware source files 
     - binary_template/src/main.c              Main program
     - binary_template/src/stm32f10x_it.c      Interrupt handlers


@par Hardware and Software environment 

  - This example runs on STM32F10x Connectivity line, High-Density, Medium-Density 
    and Low-Density Devices.
  
  - This example has been tested with STMicroelectronics STM3210C-EVAL (STM32F10x 
    Connectivity line), STM3210E-EVAL (STM32F10x High-Density) and STM3210B-EVAL
    (STM32F10x Medium-Density) evaluation boards and can be easily tailored to
    any other supported device and development board.
    To select the STMicroelectronics evaluation board used to run the example, 
    uncomment the corresponding line in stm32_eval.h file (under Utilities\STM32_EVAL)
    
  - STM3210C-EVAL Set-up 
    - Use LED1, LED2, LED3 and LED4 connected respectively to PD.07, PD.13, PF.03
      and PD.04 pins
    
  - STM3210E-EVAL Set-up 
    - Use LED1, LED2, LED3 and LED4 connected respectively to PF.06, PF0.7, PF.08
      and PF.09 pins

  - STM3210B-EVAL Set-up  
    - Use LED1, LED2, LED3 and LED4 connected respectively to PC.06, PC.07, PC.08
      and PC.09 pins 

      
@par How to use it ?  

In order to load the SysTick example with the IAP, you must do the following:

 - EWARMv5 (v5.30):
    - Open the SysTick.eww workspace
    - In the workspace toolbar select the project config:
        - STM3210C-EVAL: to configure the project for STM32 Connectivity line devices
        - STM3210B-EVAL: to configure the project for STM32 Medium-density devices
        - STM3210E-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all
    - A binary file "SysTick.bin" will be generated under "STM3210C-EVAL\Exe",
      "STM3210E-EVAL\Exe" or "STM3210B-EVAL\Exe" folder depending on the selected 
      configuration  
    - Finally load this image with IAP application

 - RIDE:
    - Open the SysTick.rprj project
    - In the configuration toolbar(Project->properties) select the project config:
        - STM3210C-EVAL: to configure the project for STM32 Connectivity line devices
        - STM3210B-EVAL: to configure the project for STM32 Medium-density devices
        - STM3210E-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->build project
    - Go to "Utilities\Binary" directory and run "hextobin.bat"
    - A binary file "SysTick.bin" will be generated under "\STM3210C_EVAL",
     "\STM3210E_EVAL" or "\STM3210B_EVAL" folder depending on the selected configuration 
    - Finally load this image with IAP application

 - RVMDK:
    - Open the SysTick.Uv2 project
    - In the build toolbar select the project config:
        - STM3210C-EVAL: to configure the project for STM32 Connectivity line devices
        - STM3210B-EVAL: to configure the project for STM32 Medium-density devices
        - STM3210E-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all target files
    - Go to "Utilities\Binary" directory and run "axftobin.bat"
    - A binary file "STM3210C-EVAL_SysTick.bin", "STM3210B-EVAL_SysTick.bin" or
      "STM3210E-EVAL_SysTick.bin" will be generated under "\Obj" folder
    - Finally load this image with IAP application

@note
 - Low-density devices are STM32F101xx and STM32F103xx microcontrollers where
   the Flash memory density ranges between 16 and 32 Kbytes.
 - Medium-density devices are STM32F101xx and STM32F103xx microcontrollers where
   the Flash memory density ranges between 32 and 128 Kbytes.
 - High-density devices are STM32F101xx and STM32F103xx microcontrollers where
   the Flash memory density ranges between 256 and 512 Kbytes.
 - Connectivity line devices are STM32F105xx and STM32F107xx microcontrollers.

 * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
 */
