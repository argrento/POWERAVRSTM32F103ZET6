/******************** (C) COPYRIGHT 2009 STMicroelectronics ********************
* File Name          : Readme.txt
* Author             : MCD Application Team
* Version            : V1.0.0
* Date               : 25/09/2009
* Description        : Description of the uClinux distribution patch for STM3210E-EVAL.
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/
  
Description
===================

The patch is to enable uClinux kernel build for STM3210E-EVAL board.
This patch is to be applied on the top of uClinux distribution source code v20090112. This will enable
the support of the Cortex-M3 CPU and STM32 MCU basics hardware.

Directory contents
==================

 + uClinux_on_stm32.patch.gz : uClinux patch containing the source code updates, to enable STM32 basic hardware support by the kernel.


Hardware environment
====================

This example runs on STMicroelectronics STM3210E-EVAL evaluation board 
and can be easily tailored to any other hardware based on STM32 high density microcontroller.

 + STM3210E-EVAL
    - Connect a null-modem female/female RS232 cable between the DB9 connector 
      CN12 (USART1) and PC serial port.
    - Connect an USB cable between the bored connector CN14 and the PC.

 + Hyperterminal configuration:
    - Word Length = 8 Bits
    - One Stop Bit
    - No parity
    - BaudRate = 19200 baud
    - flow control: None 


How to use it
=============
  
We suppose the patch file "uClinux_on_stm32.patch.gz" was saved in ~/sources directory, 
and the uClinux distribution source code v20090112 files were extracted to ~/workspace/uClinux-dist/ directory.
( Please refer to AN3012 application note for more details on how to get the uClinux distribution sources code and updates )

Run the following commands to apply this patch to the code source:

	# cd ~/workspace/uClinux-dist/
	# zcat ~/sources/uClinux_on_stm32.patch.gz | patch -p1 
	
	Or 

If the "zcat" command is absent from the system path, we can extract the patch and apply it.
Run this sequence of commands :
	# cd ~/sources/
	# gzip -d ~/sources/uClinux_on_stm32.patch.gz
	# cd ~/workspace/uClinux-dist/
	# patch -p1 < ~/sources/uClinux_on_stm32.patch

Finally we can run the  ( # make menuconfig ) from the ~/workspace/uClinux-dist/ directory 
to start the uClinux distribution configuration.

 + From the  "Vendor / Product selection" menu:
		- select "STMicroelectronics" as vendor.
		- select "STM3210E-EVAL-jffs" or "STM3210E-EVAL-MCU_Flash" as product

 + From "Kernel/Library/Defaults selection" menu:
		- select "linux-2.6.x" as kernel version.
		- select "none" as Libc version.
		- enable "Default all settings" checkbox.

After saving these settings, and quiting the configuration menu, we need to run make program to build the uClinux distribution.

	# make 
	      or 
	# make ucfront user_only romfs image


Note: 	To successfully build uClinux distribution for STM3210E-EVAL you need to install CodeSourcery toolchaine.
	The G++ Lite 2009q1 toolchain is a free version of the CodeSourcery G++ toolchain, which is an improvement 
	of the GNU toolchain for ARM processors. It can be downloaded from the CodeSourcery web site http://www.codesourcery.com/.

******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE******
